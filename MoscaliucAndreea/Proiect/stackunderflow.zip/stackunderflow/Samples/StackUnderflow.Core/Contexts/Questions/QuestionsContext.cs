﻿using Access.Primitives.IO;
using StackUnderflow.Domain.Schema.Questions.CreateNewQuestion;
using System;
using System.Collections.Generic;
using System.Text;
using static StackUnderflow.Domain.Schema.Questions.CreateNewQuestion.CreateNewQuestionResult;
using static PortExt;


namespace StackUnderflow.Domain.Core.Contexts.Questions
{
    public static class QuestionsContext
    {
        public static Port<ICreateNewQuestionResult> CreateNewQuestion(CreateNewQuestionCmd createNewQuestionCmd) =>
            NewPort<CreateNewQuestionCmd, ICreateNewQuestionResult>(createNewQuestionCmd);
    }
}
