﻿using Access.Primitives.Extensions.ObjectExtensions;
using Access.Primitives.IO;
using StackUnderflow.Domain.Schema.Questions.CreateNewQuestion;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using static StackUnderflow.Domain.Schema.Questions.CreateNewQuestion.CreateNewQuestionResult;

namespace StackUnderflow.Domain.Core.Contexts.Questions.CreateNewQuestion
{
    public class CreateNewQuestionAdapter : Adapter<CreateNewQuestionCmd , ICreateNewQuestionResult, QuestionsWriteContext, QuestionsDependencies>
    {
        public override Task PostConditions(CreateNewQuestionCmd cmd, ICreateNewQuestionResult result, QuestionsWriteContext state)
        {
            return Task.CompletedTask;
        }
        
        public async override Task<ICreateNewQuestionResult> Work(CreateNewQuestionCmd cmd, QuestionsWriteContext state, QuestionsDependencies dependencies)
        {
            var workflow = from valid in cmd.TryValidate()
                           let t = AddAnswerToQuestion(state, CreateNewQuestionCmd(cmd))
                           select t;

            var result = await workflow.Match(
                Succ: r => r,
                Fail: ex => new QuestionNotCreated(ex.Message)
                );
            return result;
        }
    }

}
