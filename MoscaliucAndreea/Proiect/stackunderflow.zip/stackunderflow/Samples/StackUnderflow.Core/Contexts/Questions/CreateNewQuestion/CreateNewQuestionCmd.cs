﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace StackUnderflow.Domain.Schema.Questions.CreateNewQuestion
{
    public class CreateNewQuestionCmd
    {
        CreateNewQuestionCmd()
        {

        }

        public CreateNewQuestionCmd(int questionID, int authorUserId, string body)
        {
            QuestionId = questionID;
            AuthorUserId = authorUserId;
            Body = body;
        }
        [Required]
        public int  QuestionId { get; set; }
        [Required]
        public int AuthorUserId { get; set; }
        [Required]
        [MinLength(10)]
        [MaxLength(500)]
        public string Body { get; set; }
    }

}
