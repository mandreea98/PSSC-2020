﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StackUnderflow.Domain.Schema.Questions.CreateNewQuestion
{
    public static partial class CreateNewQuestionResult
    {
        public interface ICreateNewQuestionResult { }

        public class QuestionCreated : ICreateNewQuestionResult
        {
            public QuestionCreated(int questionId, int authorUserId, string body)
            {
                QuestionId = questionId;
                AuthorUserId = authorUserId;
                Body = body;

            }

            public int QuestionId { get; }
            public int AuthorUserId { get; }
            public string Body { get; }
        }

        public class QuestionNotCreated : ICreateNewQuestionResult
        {
            public QuestionNotCreated(string message)
            {
                Message = message;
            }

            public string Message { get;}
        }
    }
}
