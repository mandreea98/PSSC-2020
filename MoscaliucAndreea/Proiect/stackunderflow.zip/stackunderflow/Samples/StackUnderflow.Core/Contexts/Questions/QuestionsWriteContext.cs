﻿using StackUnderflow.DatabaseModel.Models;
using StackUnderflow.EF.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace StackUnderflow.Domain.Core.Contexts.Questions
{
    public class QuestionsWriteContext
    {
        public ICollection<Question> Questions { get; }
        public ICollection<User> Users { get; }

        public QuestionsWriteContext(ICollection<Question> questions, ICollection<User> users)
        {
            Questions = questions ?? new List<Question>(0);
            Users = users ?? new List<User>(0);
        }

        public QuestionsWriteContext()
        {
        }
    }
}
