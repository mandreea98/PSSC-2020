﻿using LanguageExt;
using StackUnderflow.Domain.Schema.Questions.CreateNewQuestion;
using System;
using System.Collections.Generic;
using System.Text;

namespace StackUnderflow.Domain.Core.Contexts.Questions
{
    public class QuestionsDependencies
    {
        public Func<string> GenerateNewQuestionToken { get; set; }
    }
}