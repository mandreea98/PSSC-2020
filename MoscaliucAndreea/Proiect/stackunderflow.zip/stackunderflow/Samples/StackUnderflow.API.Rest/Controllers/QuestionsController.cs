﻿using Access.Primitives.IO;
using Access.Primitives.Extensions.ObjectExtensions;
using StackUnderflow.Domain.Core;
using StackUnderflow.Domain.Core.Contexts;
using Microsoft.AspNetCore.Mvc;
using StackUnderflow.DatabaseModel.Models;
using StackUnderflow.Domain.Schema.Questions.CreateNewQuestion;
using Access.Primitives.EFCore;
using StackUnderflow.EF.Models;
using StackUnderflow.Domain.Schema.Questions;
using System;
using System.Collections.Generic;
using LanguageExt;
using StackUnderflow.Domain.Core.Contexts.Questions;
using System.Linq;
using System.Threading.Tasks;
using StackUnderflow.EF;
using System.Collections;

namespace StackUnderflow.API.Rest.Controllers
{
    [ApiController]
    [Route("questions")]
    public class QuestionsController : ControllerBase
    {
        private readonly IInterpreterAsync _interpreter;
        private readonly DatabaseContext _dbContext;

        public QuestionsController(IInterpreterAsync interpreter, DatabaseContext dbContext)
        {
            _interpreter = interpreter;
            _dbContext = dbContext;
        }

        [HttpPost("createNewQuestion")]
        public async Task<IActionResult> CreateNewQuestion([FromBody] CreateNewQuestionCmd cmd)
        {
            var dep = new QuestionsDependencies();
            var ctx = new QuestionsWriteContext();

            var expr = from CreateNewQuestionResult in QuestionsContext.CreateNewQuestion(cmd)
                       select CreateNewQuestionResult;

            var r = await _interpreter.Interpret(expr, ctx, dep);

            _dbContext.Questions.Add(new DatabaseModel.Models.Question ( cmd.QuestionId, cmd.AuthorUserId, cmd.Body ));
            await _dbContext.SaveChangesAsync();

            return r.Match(
                succ => (IActionResult)Ok(succ.Body),
                fail => BadRequest("Question could not be created")
                );
        }
    }
}
