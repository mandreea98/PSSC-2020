﻿CREATE USER [ForumAdmin]
	For LOGIN [ForumAdmin]
GO

GRANT CONNECT TO [ForumAdmin]
Go
