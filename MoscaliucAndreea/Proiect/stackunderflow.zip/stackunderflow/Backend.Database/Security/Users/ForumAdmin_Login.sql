﻿CREATE LOGIN [ForumAdmin] WITH PASSWORD = 'Reahjh{rxdebhnk|aez%uvpdmsFT7_&#$!~<Bk|dX_r|nsxd'
